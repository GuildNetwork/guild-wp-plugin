=== Guild Network ===
Contributors: Hivepoint, Inc.
Donate link:
Tags:
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html
Requires at least: 3.5
Tested up to: 3.5
Stable tag: 0.1

Integrate Guild into the site, enabling access pass purchases

== Description ==

Integrate Guild into the site, enabling access pass purchases

== Installation ==

1)  Install and activate this plugin.  

2)  Visit https://guild.network and add a site.  This will give you a unique alphanumeric site code.

3)  Open the options page for this plugin and enter the site code there.

With this done, if you inspect your site pages, there should be a few new lines in the <head> section
that loads a script from guild.network and initializes it with your site code.

At this point, Guild will not be visible to your visitors because your site has not yet been approved.
Guild staff will be alerted that your site has gone live with Guild integration and will review it.
If approved, your pages will begin to show a Guild tab on your pages (at least for the fraction
of visitors that you configured for your site at guild.network)  and you will be notified by email.

== Frequently Asked Questions ==


== Screenshots ==


== Changelog ==

= 0.1 =
- Initial Revision
